# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np

dsm_set={'sim_path':'/Travaux/Evaporation/Modele_upperatm/Simu_results','py_path_sim':'/Travaux/Evaporation/HATP11b/Helium/Simulations/EVE_for_Science','Sr_name':'HAT_P_11','bys_name':{'by_0':'HAT_P_11b'},'T0_h':-6.,'Tf_h':4.5}
tabt_set={'rdir':'HATP11_He','Bds':{'Bd_XUV':{'mode':'raw_sp','file':'HATP11_XUV.d','limb_dark':{'mode':'unif'}},'Bd_HeI':{'mode':'raw_sp','file':'Helium_IR.d','limb_dark':{'mode':'LD_quad','coeffs':[0.26725386, 0.26492167, 0.,0.]}}}}
os_data_set={'rdir':'HATP11','os':{'os_HeI':{'dir':'Helium_IR','filelist':['HAT-P-11b_2017-08-07_'+str(i)+'.rdb' for i in np.arange(52)]+['HAT-P-11b_2017-08-12_'+str(i)+'.rdb' for i in np.arange(51)],'file_nr':'Fref_He_CARM.d','ThBd':'Bd_HeI'}}}
greg_set={'aat':{'by_0':{'tr_cd':{'Rd':5.}}}}
dic_set_set={'spg':{'Dc_anreg':{'by_0':{'aat':{'esc_tau':1e8,'Rh':{'constr':{'Rd':0.1,'Rh':1e-5}},'Tp':{'constr':{'Tp':100.}},'Up_VL':{'constr':{'VL':1e-3}}}}}}}
