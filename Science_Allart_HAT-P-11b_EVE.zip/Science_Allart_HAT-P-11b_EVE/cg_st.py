# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
from bas_f import np_exp,np_where1D
from numpy.random import RandomState
def inside_pts(Cd,Cd_lim,cond_del):
    delta=Cd-Cd_lim
    if cond_del=='inside' :ind_after_del=( delta > 0.)
    if cond_del=='outside':ind_after_del=( delta < 0.)
    return ind_after_del
def delete_inside_pt(sp,d_bys_pt_sp,Cd_bys_pt_sp,dsp,tCap,bys_name,ts,Dc_gen_an_atm,nloop,sid_index_sp,cond_lt_sp,
                       PhRt_gs,VLpr_gs,itsimu):
    idx_remaining=np.arange(dsp['npt_t'])
    for by in bys_name:	
        Cd_bys_pt_sp[by]=tCap[0:3,:]- ts[by]['c_b_Sts'][0:3,itsimu][:,None]
        d_bys_pt_sp[by]= np.sum(Cd_bys_pt_sp[by]*Cd_bys_pt_sp[by],axis=0)**0.5
        idx_remaining=idx_remaining[inside_pts(d_bys_pt_sp[by][idx_remaining],Dc_gen_an_atm[by]['Rd_ts'],'inside')]
    idx_remaining=idx_remaining[inside_pts(np.sum(tCap[0:3,idx_remaining]*tCap[0:3,idx_remaining],axis=0),ts['RSr2'],'inside')]             
    count_remain=len(idx_remaining)
    if (dsp['npt_t']>count_remain):
        dsp['npt_t']=count_remain
        tCap=tCap.take(idx_remaining,axis=1)
        cond_lt_sp=cond_lt_sp[idx_remaining]
        for by in bys_name:
            Cd_bys_pt_sp[by]=Cd_bys_pt_sp[by].take(idx_remaining,axis=1)
            d_bys_pt_sp[by]=d_bys_pt_sp[by][idx_remaining] 
        if (dsp['sid_on']==True):sid_index_sp=sid_index_sp[idx_remaining]
        if sp in PhRt_gs:PhRt_gs[sp]=PhRt_gs[sp][idx_remaining]
    return Cd_bys_pt_sp,tCap,d_bys_pt_sp,sid_index_sp,cond_lt_sp,PhRt_gs,VLpr_gs
def cg_st(sp,Dc_gs,cond_lt_sp,tCap,sid_index_sp,dt_s_s,t_s_h,PhRt_gs,VLpr_gs,cpt_childgs):
    dsp=Dc_gs[sp]
    npt_t=dsp['npt_t']
    tchgst=PhRt_gs[sp]
    Rde_Rts=dsp['Rde']['Rde_Rts']
    for De_sp in Rde_Rts:
        tchgst+=np.repeat(Rde_Rts[De_sp],npt_t)
    cond_chgst=(np.array([RandomState(sid).random_sample(1)[0] for sid in sid_index_sp]) <  1. - np_exp(-dt_s_s*tchgst))
    if (True in cond_chgst):
        idx_chstat=np_where1D(cond_chgst)
        dsp['npt_t']-=len(idx_chstat)
        tCap=np.delete(tCap,idx_chstat,axis=1)
        cond_lt_sp=np.delete(cond_lt_sp,idx_chstat)         
        if (dsp['sid_on']==True):sid_index_sp=np.delete(sid_index_sp,idx_chstat)
    return tCap,sid_index_sp


