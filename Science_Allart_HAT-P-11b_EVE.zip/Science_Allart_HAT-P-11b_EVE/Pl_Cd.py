# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
from math import cos,sin,sqrt,atan,tan,pi
import numpy as np
from scipy.optimize import newton
def Pl_Cd_Sts(by,ts,dsm):
    ts_by=ts[by]
    ecc=ts_by['ecc']  
    a_Pl=ts_by['a_Pl'] 
    omega_p=ts_by['omega_p']
    t_ob_Sts = dsm['tSts']/(24.*365.25)
    omega_Rd=ts_by['omega_Rd']
    c_om=cos(omega_Rd)
    s_om=sin(omega_Rd)
    True_anom_TR=(pi/2.)-omega_Rd
    Ecc_anom_TR=2.*atan( tan(True_anom_TR/2.)*sqrt((1.-ecc)/(1.+ecc)) )
    Mean_anom_TR=Ecc_anom_TR-ecc*sin(Ecc_anom_TR)
    if (Mean_anom_TR<0.):Mean_anom_TR+=2.*pi
    Mean_anom=Mean_anom_TR+omega_p*t_ob_Sts
    Ecc_anom=np.array([newton(Kepler_func,Mean_anom_t,args=(Mean_anom_t,ecc,)) for Mean_anom_t in Mean_anom])
    c_ecc=np.cos(Ecc_anom)
    s_ecc=np.sin(Ecc_anom)
    DPl_nr=(1.-ecc*c_ecc)
    ts_by['DPl_Sts']=DPl_nr*a_Pl
    b_Pl_nr=sqrt(1.-ecc*ecc)
    X0_p_nr=(c_ecc-ecc)  
    Y0_p_nr=b_Pl_nr*s_ecc    
    VX0_p_nr =-omega_p*s_ecc/DPl_nr
    VY0_p_nr = omega_p*b_Pl_nr*c_ecc/DPl_nr
    XobE_p_nr =   X0_p_nr*s_om  +  Y0_p_nr*c_om
    YobE_p_nr =  -X0_p_nr*c_om  +  Y0_p_nr*s_om
    VXobE_p_nr =  VX0_p_nr*s_om + VY0_p_nr*c_om
    VYobE_p_nr = -VX0_p_nr*c_om + VY0_p_nr*s_om
    ts_by['phi_pl_Sts']=np.arcsin(ts_by['RPl']/ts_by['DPl_Sts'])
    ts_by['gamma_pl_Sts']=np.arctan2(Y0_p_nr,b_Pl_nr*b_Pl_nr*(ecc + X0_p_nr))
    ts_by['dzet_pl_Sts']=np.arctan2(Y0_p_nr,X0_p_nr)
    c_b_Sts=Cd_obE_to_sim(ts,by,XobE_p_nr,YobE_p_nr,0.,VobE_p=[VXobE_p_nr,VYobE_p_nr,0.])*a_Pl
    ts_by['c_b_Sts']=c_b_Sts
    return None
def Cd_obE_to_sim(ts,by,XobE_p,YobE_p,ZobE_p,VobE_p=None):
    Inclin=ts[by]['Inclin']
    c_inc=cos(Inclin)
    s_inc=sin(Inclin)
    Xsky_p = XobE_p*c_inc - ZobE_p*s_inc 
    Ysky_p = YobE_p
    Zsky_p = XobE_p*s_inc + ZobE_p*c_inc 
    if VobE_p is not None:
        VXsky_p= VobE_p[0]*c_inc - VobE_p[2]*s_inc
        VYsky_p= VobE_p[1]
        VZsky_p= VobE_p[0]*s_inc + VobE_p[2]*c_inc 
    if by=='by_0':
        Xsim_p = Xsky_p
        Ysim_p = Ysky_p
        Zsim_p = Zsky_p
        if VobE_p is not None:
            VXsim_p= VXsky_p
            VYsim_p= VYsky_p
            VZsim_p= VZsky_p
    if VobE_p is not None:
        c_b_Sts=np.stack((Xsim_p,Ysim_p,Zsim_p,VXsim_p,VYsim_p,VZsim_p))
    else:
        c_b_Sts=np.stack((Xsim_p,Ysim_p,Zsim_p))
    return c_b_Sts
def Cd_sim_to_obE(ts,by,Xsim_p,Ysim_p,Zsim_p):
    Xsky_p = Xsim_p
    Ysky_p = Ysim_p
    Zsky_p = Zsim_p
    Inclin=ts[by]['Inclin'] 
    c_inc=cos(Inclin)
    s_inc=sin(Inclin)
    XobE_p = Xsky_p*c_inc + Zsky_p*s_inc
    YobE_p = Ysky_p
    ZobE_p =-Xsky_p*s_inc + Zsky_p*c_inc
    return XobE_p,YobE_p,ZobE_p
def Kepler_func(Ecc_anom,Mean_anom,ecc):
    delta=Ecc_anom-ecc*np.sin(Ecc_anom)-Mean_anom
    return delta   
