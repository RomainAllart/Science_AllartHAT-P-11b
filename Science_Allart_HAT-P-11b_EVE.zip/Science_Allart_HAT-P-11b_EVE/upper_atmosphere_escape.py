# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
from cst_d import tabg,Mjup,Msun,Rsun,Rjup,AU_1,Msn,Rsn,c_lt
from settings import *
from bas_f import St_range,stop
from math import cos,pi
import numpy as np
from Pl_Cd import Pl_Cd_Sts
import os as os_system
from lanc_Cd import lanc_Cd,clP
from gs_d import gs_d
from cg_st import delete_inside_pt,cg_st
from init1 import init_gs
from init0 import read_os,read_ref  
from trs_sp import cal_th,odat
from s_gds import define_st_pl_gds 
from copy import deepcopy



def upper_atmosphere_escape():
    os_system.chdir(dsm_set['sim_path'])
    Sr_name=dsm_set['Sr_name']
    dir_simus=Sr_name
    dir_simus_Tp=dir_simus+'_Tp'
    if not os_system.path.exists(dir_simus_Tp):
        os_system.makedirs(dir_simus_Tp)
    os_system.chdir(dsm_set['sim_path']+'/'+dir_simus_Tp)
    greg=deepcopy(greg_set)
    dsm=deepcopy(dsm_set)
    sn={}
    bdg=deepcopy({'by_0':{}})
    dsm['dt_s']=0.01
    dsm['tSts']=St_range(dsm['T0_h'],dsm['Tf_h'],dsm['dt_s']/60.)
    dsm['nSts']=len(dsm['tSts'])
    dsm['t_s_h']=dsm['T0_h']
    dsm['T0']=dsm['T0_h']/(24.*365.25)
    dsm['Tf']=dsm['Tf_h']/(24.*365.25)
    dsm['t_s']=dsm['T0']
    dsm['dt_s_h']=dsm['dt_s']/60.
    dsm['dt_s_s']=dsm['dt_s']*60.
    dsm['dt_s']/=(24.*365.25*60.)
    dsm['nloop']=0
    dsm['itsimu']=0
    rdg=np.random.RandomState(100)
    bys_name=dsm['bys_name']   
    ts_all={'HAT_P_11':{'Sr':{ 'MSr':0.802,'RSr':0.683,},'HAT_P_11b':{'t_0':54957.813207  ,       'period':4.8878024, 'ecc':0.2644,'omega_deg':342.2,'RpRs':0.05856000,'RPl':4.36*Rsn/Rjup,'aRs':16.50,'a_Pl':0.05240844079741304,'Inclin_cat':88.99,'MPl':27.74*Msn/Mjup,'b_impact':0.29084405647393891}},}
    ts=ts_all[Sr_name]['Sr']
    ts['RSr']*=Rsun/AU_1 
    ts['RSr2']=ts['RSr']**2.
    for by in bys_name:
        ts[by]=ts_all[Sr_name][bys_name[by]]
        ts[by]['Inclin']=(-90.+ts[by]['Inclin_cat'])*pi/180.
        ts[by]['omega_Rd']=ts[by]['omega_deg']*pi/180.
        ts[by]['MPl']*=Mjup/Msun
        ts[by]['RPl']*=Rjup/AU_1
        ts[by]['omega_p']=2.*pi*365.2425/ts[by]['period']
    Dc_collgd={}
    tabt=read_ref(tabt_set,dsm['py_path_sim'],dsm['tSts'])
    os_data=read_os(os_data_set,tabt,dsm['py_path_sim'],dsm['tSts'],dsm['dt_s_h'],ts['by_0'],dsm['nSts'])		                
    Dc_gs,abp,d_PrP,gsgreg,tabgs,sid_index=init_gs(tabg,deepcopy(dic_set_set),sn,{'by_0':['Bd_HeI']},ts,dsm,greg,tabt,Dc_collgd)
    define_st_pl_gds(sn,bdg,ts,tabt,greg,dsm)
    t_s=dsm['t_s']
    itsimu=dsm['itsimu']
    dt_s=dsm['dt_s']				
    nloop=dsm['nloop']
    for by in bys_name:
        Pl_Cd_Sts(by,ts,dsm)
    while (itsimu<dsm['nSts']-1):
        for by in greg['aat']:
            if (nloop==0):greg['aat'][by]['Rd_ts']=greg['aat'][by]['tr_cd']['Rd']*ts[by]['RPl']
        d_Sr_pt_gs={}
        phi_pt_gs={}							
        vRDo={} 						
        cond_lt_gs={}
        sp='spg'
        dn_pt=0
        dsp_anreg=gsgreg[sp]
        Dc_gas=Dc_gs[sp]		
        for by in dsp_anreg:
            if ('aat' in dsp_anreg[by]):
                dspba=gsgreg[sp][by]['aat']	
                if (nloop==0):
                    clP(sp,dspba,dsm['dt_s_s'],Dc_gas,ts[by],greg['aat'][by],by,nloop,rdg,
                                     gsgreg,greg,dsm['itsimu'])
                if Dc_gas['dn_pt'][by]>0:
                    tabgs[sp]=lanc_Cd(by,Dc_gas,rdg,dspba,ts,greg['aat'][by],tabgs[sp],itsimu)
                    dn_pt+=Dc_gas['dn_pt'][by]
        if (dn_pt>0):
            Dc_gas['npt_t']+=dn_pt
            if (Dc_gas['sid_on']==True):
                sid_index[sp]=np.append(sid_index[sp],sid_index['id_last']+1+np.arange(dn_pt,dtype=int))+rdg.random_integers(1,10)
                sid_index['id_last']=sid_index[sp][-1]
        if (Dc_gas['npt_t']>0):
            tCap=tabgs[sp]
            xpt_sp=tCap[0,:]
            ypt_sp=tCap[1,:]
            zpt_sp=tCap[2,:]									
            d_Sr_pt_sp=np.sqrt(xpt_sp*xpt_sp+ypt_sp*ypt_sp+zpt_sp*zpt_sp)    
            phi_pt_gs[sp]={}
            for by in bys_name:  
                Dc_by=ts[by]
                phi_pt_gs[sp][by]=np.arccos((Dc_by['c_b_Sts'][0,itsimu]*xpt_sp+Dc_by['c_b_Sts'][1,itsimu]*ypt_sp+Dc_by['c_b_Sts'][2,itsimu]*zpt_sp)/(d_Sr_pt_sp*Dc_by['DPl_Sts'][itsimu] ))
            cond_lt_sp=np.repeat(True,Dc_gas['npt_t'])
            d_Sr_pt_gs[sp]=d_Sr_pt_sp
            for by in bys_name: 
                phi_pl=ts[by]['phi_pl_Sts'][itsimu]
                cond_lt_sp = (cond_lt_sp & ((phi_pt_gs[sp][by] > phi_pl) | (d_Sr_pt_gs[sp] < ts[by]['DPl_Sts'][itsimu]*cos(phi_pl))))  
            cond_lt_gs[sp]=cond_lt_sp
            vRDo[sp]=-(AU_1/31557600.)*((xpt_sp[cond_lt_sp]*tCap[3,cond_lt_sp])+(ypt_sp[cond_lt_sp]*tCap[4,cond_lt_sp])+(zpt_sp[cond_lt_sp]*tCap[5,cond_lt_sp]))/d_Sr_pt_sp[cond_lt_sp]  
        PhRt_gs={}
        VLpr_gs={}
        if (Dc_gs[sp]['npt_t']>0):
            cond_lt_sp=cond_lt_gs[sp]
            n_lt_sp=np.sum(cond_lt_sp)
            dsp=Dc_gs[sp]
            if ('PhI' in dsp) and (n_lt_sp>0):
                Ph_inputs={'dist_Sr_pt':d_Sr_pt_gs[sp][cond_lt_sp]}
                PhRt_gs[sp]=np.zeros(dsp['npt_t'])
                PhRt_gs[sp][cond_lt_sp]=dsp['PhI']['PhRt_func'](Ph_inputs)
            rb_sp=np.zeros(dsp['npt_t'])
            rb_sp_lines={}
            for pRd_proc in dsp['pRd_proc']:
                pces_prop=d_PrP[pRd_proc]
                pRd_sp_inputs={}
                pRd_sp_inputs['lb_pt_tab']=pces_prop['w0']*(1.+(np.array(vRDo[sp])/c_lt))    
                rb_sp_proc=pces_prop['rb_func'](pRd_sp_inputs) 
                if pRd_proc in rb_sp_lines:          
                    rb_sp_lines[pRd_proc][cond_lt_sp]=rb_sp_proc
                rb_sp[cond_lt_sp]+=rb_sp_proc
            tabgs[sp]=gs_d(dsm,Dc_gs[sp],tabgs[sp],d_Sr_pt_gs[sp],sid_index[sp],
										  rb_sp_lines,rb_sp,ts,bys_name,d_PrP,cond_lt_sp)
        t_s+=dt_s
        itsimu+=1
        dsm['t_s']=t_s
        dsm['t_s_h']=t_s*8766.
        dsm['itsimu']=itsimu
        dbp={}
        cd_gs={}
        sp='spg'
        dsp=Dc_gs[sp]
        dbp[sp]={}
        cd_gs[sp]={}
        if (dsp['npt_t']>0):
            cd_gs[sp],tabgs[sp],dbp[sp],sid_index[sp],cond_lt_gs[sp],PhRt_gs,VLpr_gs=delete_inside_pt(sp,dbp[sp],cd_gs[sp],dsp,tabgs[sp],bys_name,ts,greg['aat'],nloop,sid_index[sp],cond_lt_gs[sp],PhRt_gs,VLpr_gs,itsimu)
        if (nloop in tabt['id_tSts_Th']):
            cal_th(tabt,tabgs,ts,sn,bdg,abp,greg,gsgreg,cd_gs,dbp,dsm,Dc_gs)
            if (len(os_data)>0):odat(tabt,os_data,dsm['t_s_h'],dsm['dt_s_h'],ts,bys_name,nloop,dsm['itsimu'])
        cpt_childgs={}
        cpt_childgs[sp]=np.empty([6,0],dtype=float)                  
        if (Dc_gs[sp]['npt_t']>0):
            tabgs[sp],sid_index[sp]=cg_st(sp,Dc_gs,cond_lt_gs[sp],tabgs[sp],sid_index[sp],dsm['dt_s_s'],dsm['t_s_h'],PhRt_gs,VLpr_gs,cpt_childgs)
        nloop+=1
        dsm['nloop']=nloop
        print 'Nloop',nloop
    sim_path=dsm['sim_path']
    os_system.chdir(sim_path)
    Capath_dir_simus=sim_path+'/'+dir_simus
    if os_system.path.isdir(Capath_dir_simus)==0:
	os_system.rename(sim_path+'/'+dir_simus_Tp,Capath_dir_simus)	
    else:
	ind_file=1
	while os_system.path.isdir(Capath_dir_simus+'_vers'+str(ind_file)):ind_file+=1
	os_system.rename(sim_path+'/'+dir_simus_Tp,Capath_dir_simus+'_vers'+str(ind_file))
    return None
