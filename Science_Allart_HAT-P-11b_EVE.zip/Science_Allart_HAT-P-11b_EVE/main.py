# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
from upper_atmosphere_escape import upper_atmosphere_escape
upper_atmosphere_escape()
