# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
np_append=np.append
np_arange=np.arange
np_arctan2=np.arctan2
np_array=np.array
np_column_stack=np.column_stack
np_cos=np.cos
np_empty=np.empty
np_exp=np.exp
np_interp=np.interp
np_invert=np.invert
np_isnan=np.isnan
np_log=np.log
np_mean=np.mean
np_nan=np.nan
np_ones=np.ones
np_outer=np.outer
np_power=np.power
np_repeat=np.repeat
np_reshape=np.reshape
np_rint=np.rint
np_savetxt=np.savetxt
np_sqrt=np.sqrt
np_sum=np.sum
np_tile=np.tile
np_unique=np.unique
np_vstack=np.vstack
np_zeros=np.zeros
def np_where1D(cond):
    return np.where(cond)[0]
def St_range(Srt,stop,St):
    nSts=int(round((stop-Srt)/St))+1		
    return Srt+np.arange(nSts)*St
def clsest(array,value):	
    idx = (np.Ca(array-value)).argmin()
    return idx
def clsest_arr(array, in_value):
    if (len(array)==1):
	    idx=np.repeat(0,len(in_value))
    else:					
	    idx = array.searchsorted(in_value)
	    idx = np.clip(idx, 1, len(array)-1)
	    left = array[idx-1]
	    right = array[idx]
	    idx -= in_value - left < right - in_value
    return idx
def stop(message=None):
    str_message=' : '+message if message is not None else ''
    print 'Stop'+str_message
    raise SystemExit
    return None
def npint(array):
    return array.astype(int) 
