# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
from math import pi
def gs_d(dsm,dsp,tCap,d_Sr_pt_sp,sid_index,rb_sp_lines,rb_sp,ts,bys_name,d_PrP,cond_lt_sp):
    return rk4(dsm['t_s'],dsm['dt_s'],tCap,force,{'itsimu':dsm['itsimu'],'rb':rb_sp,'d_Sr_pt':d_Sr_pt_sp,'ts':ts,'bys_name':bys_name})
def rk4(x, h, y, f ,extras):
    k1 = h * f(x        , y         , extras)
    k2 = h * f(x + 0.5*h, y + 0.5*k1, extras)
    k3 = h * f(x + 0.5*h, y + 0.5*k2, extras)
    k4 = h * f(x + h    , y + k3    , extras)
    return y + (k1 + 2*(k2 + k3) + k4)/6.0    
def force(t_s,cpt,extras):
    ts=extras['ts']
    Fxyz_m=-cpt[0:3,:]*4.*pi**2.*ts['MSr']*(1.-extras['rb'])/extras['d_Sr_pt']**3.
    pl_pos=ts['by_0']['c_b_Sts'][0:3,extras['itsimu']]
    Fxyz_m+=-pl_pos[:,None]*4.*pi**2.*ts['by_0']['MPl']/(np.sum(pl_pos*pl_pos)**1.5 )
    for by in extras['bys_name']:
        pl_pos=ts[by]['c_b_Sts'][0:3,extras['itsimu']]
        d_pl_pt=cpt[0:3,:]-pl_pos[:,None]
        d_pl_pt3=np.sum(d_pl_pt*d_pl_pt,axis=0)**1.5
        Fxyz_m+=-d_pl_pt*4.*pi**2.*ts[by]['MPl']/d_pl_pt3       
    deriv=np.vstack((cpt[3:6,:],Fxyz_m))
    return deriv
