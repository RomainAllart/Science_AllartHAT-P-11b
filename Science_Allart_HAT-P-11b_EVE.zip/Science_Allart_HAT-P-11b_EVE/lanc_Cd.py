# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
from math import sqrt,cos,sin,pi
from cst_d import k_boltz,AU_1_m,AU_1
from Pl_Cd import Cd_obE_to_sim
def clP(sp,dspba,dt_s_s,dsp,ts_by,dg_ab,by,nloop,rdg,gsgreg,greg,itsimu):
    dspba['Tp_ts']=dspba['Tp']['function'](1,np.array([dg_ab['Rd_ts']]),'Tp',ts_by,dg_ab,dspba)[0]
    dspba['UpVL_ts']=dspba['Up_VL']['function'](1,np.array([dg_ab['Rd_ts']]),'Up_VL',ts_by,dg_ab,dspba)[0]*31557600./AU_1   
    dspba['ThVL_ts']=sqrt(k_boltz*dspba['Tp_ts']/dsp['gg'])*31557600./AU_1_m
    dsp['dn_pt'][by]=int((((dspba['esc_tau']*pow(ts_by['a_Pl']/ts_by['DPl_Sts'][itsimu],2.)*dt_s_s)/(dsp['gg']*1e3))/1e26))
    return None
def ang_lch(dg_ab):
    dg_ab['lch']={}
    def inv_f(Rd_loc_th,Rd_loc_phi):
        return -pi+Rd_loc_th*(2.*pi),np.arcsin(-1.+Rd_loc_phi*2.)
    dg_ab['lch']['inv_f']=inv_f
    return None
def lanc_Cd(by,dsp,rdg,dspba,ts,dg_ab,tCap,itsimu):
    ts_by=ts[by]
    dn_pt_by=dsp['dn_pt'][by]	
    cpt_lanc=np.zeros([6,dn_pt_by])
    tt_lanc,phi_lanc=dg_ab['lch']['inv_f'](rdg.random_sample(dn_pt_by),rdg.random_sample(dn_pt_by))
    Rd_x,Rd_y,Rd_z=np.repeat(dg_ab['Rd_ts'],3.)
    x_tan=Rd_x*np.cos(tt_lanc)*np.cos(phi_lanc)
    y_tan=Rd_y*np.sin(tt_lanc)*np.cos(phi_lanc)
    z_tan=Rd_z*np.sin(phi_lanc)
    common_ang=ts_by['gamma_pl_Sts'][itsimu]+ts_by['omega_Rd']
    XobE_p =   x_tan*sin(common_ang) + y_tan*cos(common_ang)
    YobE_p =  -x_tan*cos(common_ang) + y_tan*sin(common_ang)      
    cpt_lanc[3:6,:]+=(np.stack((XobE_p,YobE_p,z_tan))*dspba['UpVL_ts']/dg_ab['Rd_ts'])+(np.stack((rdg.randn(dn_pt_by),rdg.randn(dn_pt_by),rdg.randn(dn_pt_by)))*dspba['ThVL_ts'])        
    cpt_lanc[0:3,:]=Cd_obE_to_sim(ts,by,XobE_p,YobE_p,z_tan)
    cpt_up=np.append(tCap,ts_by['c_b_Sts'][:,itsimu][:,None]+cpt_lanc,axis=1)
    return cpt_up
