# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
from bas_f import stop,npint,np_interp,np_where1D
import os as os_system
from scipy import stats
import astropy.convolution.convolve as astro_conv
from copy import deepcopy
from math import sqrt
def read_ref(tabt_set,py_path_sim,tSts):
    tabt=deepcopy(tabt_set)
    dtss_path=py_path_sim+'/Reference_data/'+tabt['rdir']
    def dir_crea(mode_str,Bd_str):
        dir_name='tabt/Th_'+mode_str+'_'+Bd_str											
        if not os_system.path.exists(dir_name):os_system.makedirs(dir_name)	
        return None
    Bd_dtss=tabt['Bds']
    Bds_names=[]
    w_st_Bds=[]  
    for Bd_id in Bd_dtss:
        Bd_set=Bd_dtss[Bd_id]
        rlbT,Bd_set['rF_one'],Bd_set['rFE']=np.loadtxt(dtss_path+'/'+Bd_set['file']).T
        Bd_set['rlbT']=rlbT
        Bds_names+=[Bd_id]
        w_st_Bds+=[rlbT[0]]
        Bd_set['npix']=len(rlbT)
        dw_pixels=np.roll(rlbT,-1)-rlbT
        Bd_set['dw_Bd']=dw_pixels[0:-1][0]
    tabt['Bds_order']=list(np.array(Bds_names)[np.array(w_st_Bds).argsort()])
    Fone_gb=np.empty(0,dtype=float)
    lb_gb=np.empty(0,dtype=float)
    dlb_gb=np.empty(0,dtype=float)
    ist_Bd=0
    ipix_st_end={}
    for Bd_id in tabt['Bds_order']:
        Bd_set=Bd_dtss[Bd_id]
        Fone_gb=np.append(Fone_gb,Bd_set['rF_one'])
        lb_gb=np.append(lb_gb,Bd_set['rlbT'])
        dlb_gb=np.append(dlb_gb,np.repeat(Bd_set['dw_Bd'],Bd_set['npix']))
        ipix_st_end[Bd_id]=[ist_Bd,ist_Bd+Bd_set['npix']-1]
        ist_Bd+=Bd_set['npix']
    tabt['Fone_gb']=Fone_gb
    tabt['lb_gb']=lb_gb
    tabt['dlb_gb']=dlb_gb
    tabt['npix_gb']=ist_Bd
    tabt['ipix_st_end']=ipix_st_end
    id_tSts_Th=np.empty(0,dtype=int)
    for trange in [[-6.,4.8]]:
        id_tSts_Th=np.append(id_tSts_Th,np.where((tSts>=trange[0]) & (tSts<=trange[1]))[0])
    tabt['id_tSts_Th']=id_tSts_Th
    return tabt    
def Th_to_spinst(lbe_tab,dw_Bd,FE,ins_d,inst_subw_table,subin_eds):
    FE_inst=astro_conv(FE,ins_d['kernel'],boundary='extend')           
    F_inst_sub=np_interp(inst_subw_table,lbe_tab,FE_inst,left=0.,right=0.)
    F_inst=stats.binned_statistic(inst_subw_table,F_inst_sub,statistic='mean',bins=subin_eds)[0]
    return F_inst   
def read_os(os_data_set,tabt,py_path_sim,tSts,dt_s_h,ts_by0,nSts):
    os_data=deepcopy(os_data_set)
    dtss_path=py_path_sim+'/observed_data/'+os_data['rdir']
    t_0_main_by=ts_by0['t_0']
    P_main_by=ts_by0['period']
    os_dtss=os_data['os']
    for os_id in os_dtss:
        os_set=os_dtss[os_id]
        Bd_id=os_set['ThBd']
        Bd_os=tabt['Bds'][Bd_id]
        rlbT=Bd_os['rlbT']            
        dw_Bd=Bd_os['dw_Bd'] 
        ins_d={}
        ins_d['dw_inst']=0.058528
        nk=2*(int(0.21256489184577276/dw_Bd)+1)+1
        kernel_Tp=np.exp(-np.power(dw_Bd*(np.arange(nk)-(nk-1.)/2.)/(sqrt(2.)*0.057202608139326205),2.))
        ins_d['kernel']=kernel_Tp/np.sum(kernel_Tp)
        os_set['ins_d']=ins_d
        common_path=dtss_path+'/'+os_set['dir']+'/'
        os_list=[common_path+id_file for id_file in os_set['filelist']]
        n_Xpo=len(os_list)
        dir_name='os_data/'+os_id
        if not os_system.path.exists(dir_name):os_system.makedirs(dir_name)
        os_set['k4_f_created']=False
        t_tab=np.zeros([2,n_Xpo],dtype=float)
        for iXp,id_file in enumerate(os_list):
            Xp_data=np.loadtxt(id_file)
            os_stlb_table,os_endlb_table,fx_loc,e_loc,time_column=Xp_data.T
            t_tab[:,iXp]=time_column[[0,1]]
            if iXp==0:
                os_set['lb_os']=0.5*(os_stlb_table+os_endlb_table)
                fx_os=fx_loc
                e_os=e_loc
            else: 
                fx_os=np.vstack((fx_os,fx_loc))
                e_os=np.vstack((e_os,e_loc))
        Ph_raw=(t_tab-t_0_main_by)/P_main_by
        Ph_orb = Ph_raw - npint(Ph_raw+np.sign(Ph_raw)*0.5)
        tim_os=Ph_orb*P_main_by*24.
        if (n_Xpo>1):
            w_tsort=tim_os[0,:].argsort()  
            os_set['tim_os']=tim_os[:,w_tsort]
            os_set['fx_os']=(fx_os.T)[:,w_tsort]
            os_set['e_os']=(e_os.T)[:,w_tsort]
        if (n_Xpo==1):
            npts=len(fx_os)
            os_set['tim_os']=tim_os
            os_set['fx_os']=fx_os.reshape(npts,1)
            os_set['e_os']=e_os.reshape(npts,1)
        os_set['Th_Xp_in_os']=np.zeros(n_Xpo)
        id_Xp_tSts={}  
        maxtSt_to_do=0
        for id_Th in tabt['id_tSts_Th']:
            id_Xp_tSt=np.where( ( (tSts[id_Th]+dt_s_h) >= os_set['tim_os'][0,:] ) & ( tSts[id_Th]<=os_set['tim_os'][1,:] ) )[0]   
            id_Xp_tSts[id_Th]=id_Xp_tSt
            if len(id_Xp_tSt)>0:                
                os_set['Th_Xp_in_os'][id_Xp_tSt]+=1
                maxtSt_to_do=id_Th
        os_set['maxtSt_to_do']=maxtSt_to_do
        os_set['FE_tXp_all']=np.repeat([np.zeros(Bd_os['npix'])],n_Xpo,axis=0)
        os_set['id_Xp_tSts']=id_Xp_tSts
        if ('file_nr' in os_set):
            Xp_data=np.loadtxt(common_path+os_set['file_nr'])
            stlbe_ref,endlbe_ref,os_set['fx_ref'],os_set['e_rf']=Xp_data.T
            os_set.pop('file_nr')
        dw_os=os_endlb_table-os_stlb_table
        os_set['dw_os']=dw_os
        subin_eds=np.append(os_stlb_table,os_endlb_table[-1])
        os_set['subin_eds']=subin_eds
        n_sub_tab=np.round(dw_os/dw_Bd).astype(int)            
        dw_adj=dw_os/n_sub_tab
        inst_subw_table=np.empty(0)
        for ios in xrange(len(dw_os)):
            inst_subw_table=np.append(inst_subw_table,subin_eds[ios]+0.5*dw_adj[ios]+dw_adj[ios]*np.arange(n_sub_tab[ios]))
        os_set['inst_subw_table']=inst_subw_table
        os_set['rF_Ths']=Th_to_spinst(rlbT,dw_Bd,Bd_os['rFE'],os_set['ins_d'],inst_subw_table,subin_eds)
        os_set['ospix_k4']=[]
        for lb_k4 in [[10826.,10834.]]:
            ospix_k4=np_where1D((os_set['lb_os']>=lb_k4[0]) & (os_set['lb_os']<=lb_k4[-1]))
            os_set['ospix_k4']+=[ospix_k4]
        if len(os_set['ospix_k4'])==0:stop('Range for k4 comparison outside of spectra')
        os_set.pop('dir')            
        os_set.pop('filelist')
    os_data.pop('rdir')
    os_data=os_data.pop('os')
    return os_data
