# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
from cst_d import amu,alpha,c_lt,AU_1_m ,G_usi,Msun,h_planck
from bas_f import np_where1D,np_arange,np_interp
from math import pi
from CrS import return_crs
import numpy as np
from An_Th import Anreg_functions,An_vl_functions
from CrS import crs_sp
from scipy import integrate
from lanc_Cd import ang_lch
def def_prop_loc(pces_prop,dsm):
    pces_prop['lambda_0']=pces_prop['w0']*1e-10
    pces_prop['sigma_vu0']=alpha*pces_prop['f_os']
    pces_prop['hwhm_lor']=pces_prop['delta_damping']*pces_prop['lambda_0']*1e-3
    return None
def init_gs(tabg,dic_set,sn,Dc_by_Oc,ts,dsm,greg,tabt,Dc_collgd):
    st_gd_width=2.*ts['RSr']
    sn['st_gd_width']=st_gd_width
    sn['n_db']=10
    sn['sf_box']=pow(st_gd_width*AU_1_m/(2.*sn['n_db']+1.),2.)
    sn['db']=st_gd_width/(2.*sn['n_db']+1.)
    greg['Ca_bys_atm']={}
    if len(greg['aat'])>0:
        greg['by_Antm_sp']={}
        for by in greg['aat']:    
            Dc_gen_Antm_by=greg['aat'][by]
            Dc_gen_Antm_by['mn_m']=1.2*amu
            greg['by_Antm_sp'][by]=set()
    Dc_gases={}
    gsgreg={}
    tabgs={}
    abp={}
    d_PrP={}
    Dc_ltproc={'pRd':[],'Ph':[]}
    sid_index={}	
    sid_index['id_last']=0
    Ca_ls_Bds_proc=[]
    Ca_ls_Bds_by=[]         
    tabt['Ca_ls_Bds_pix']={}
    tabt['Ca_ls_bys']=[]
    for by in Dc_by_Oc:
        tabt['Ca_ls_bys']+=[by]
        for Bd_id in Dc_by_Oc[by]: 
                if Bd_id not in Ca_ls_Bds_by:Ca_ls_Bds_by+=[Bd_id]
    tabt['etr_pRd_proc']={}
    tabt['Ca_ls_sp']=[]
    sp_list=dic_set.keys()
    sp='spg'
    dic_sp_Tp=dic_set[sp]
    dic_sp_Tp.update(tabg[sp])
    dsp_anreg=dic_sp_Tp.pop('Dc_anreg')
    tabgs[sp]=np.empty([6,0],dtype=float)
    sid_index[sp]=np.empty([0],dtype=int)
    dic_sp_Tp['npt_t']=0
    Dc_all_pceses={'tr1':{'gs':'spg','w0':10832.057472,'f_os':5.9902e-02,'delta_damping':1.0216e+07/(4.*pi)},'tr2':{'gs':'spg','w0':10833.216751,'f_os':1.7974e-01,'delta_damping':1.0216e+07/(4.*pi)},'tr3':{'gs':'spg','w0':10833.306444,'f_os':2.9958e-01,'delta_damping':1.0216e+07/(4.*pi)},}  
    for by in dsp_anreg:
        if ('dn_pt' not in dic_sp_Tp):dic_sp_Tp['dn_pt']={}                       
        dic_sp_Tp['dn_pt'][by]=0
        ang_lch(greg['aat'][by])    
        Bd_dtss=tabt['Bds']
        dic_sp_Tp['Ca_proc']={'tr1':{},'tr2':{},'tr3':{}}
        local_outputs={'vl_for_Caproc':False,'Tp_for_Caproc':False}
        dic_sp_Tp['Ca_ls_Bds_proc']=[]
        for Ca_proc in dic_sp_Tp['Ca_proc']:
            pces_prop=dic_sp_Tp['Ca_proc'][Ca_proc]
            pces_prop.update(Dc_all_pceses[Ca_proc])
            def_prop_loc(pces_prop,dsm)
            pces_prop['sp_res']=pces_prop['w0']*10./c_lt
            pces_prop['Bds']=[]
            pces_prop['lb_Bds']={}
            pces_prop['lb_Bds_calc']={}
            pces_prop['n_pix_calc']={} 
            pces_prop['n_pix']={}
            pces_prop['ipix_st_Bd']={}
            for Bd_id in tabt['Bds_order']:
                Bd_set=Bd_dtss[Bd_id]
                pces_prop['lb_Bds_calc'][Bd_id]={}
                pces_prop['n_pix_calc'][Bd_id]={}
                wov=np_where1D((Bd_set['rlbT']>=pces_prop['w0']*((-300./c_lt)+1.)) & (Bd_set['rlbT']<=pces_prop['w0']*((100./c_lt)+1.)))   
                if len(wov)>0:
                    pces_prop['Bds']+=[Bd_id] 
                    dic_sp_Tp['Ca_ls_Bds_proc']+=[Bd_id]
                    pces_prop['lb_Bds'][Bd_id]=Bd_set['rlbT'][wov]
                    pces_prop['n_pix'][Bd_id]=len(wov)
                    pces_prop['ipix_st_Bd'][Bd_id]=wov
                    if Bd_id not in Ca_ls_Bds_proc:                                
                        Ca_ls_Bds_proc+=[Bd_id]
                    if Bd_id not in tabt['Ca_ls_Bds_pix']:
                        tabt['Ca_ls_Bds_pix'][Bd_id]=wov
                    else:
                        tabt['Ca_ls_Bds_pix'][Bd_id]=np.setxor1d(tabt['Ca_ls_Bds_pix'][Bd_id],wov)
                    dw_Bd=Bd_set['dw_Bd']
                    min_lb_Bd=pces_prop['lb_Bds'][Bd_id][0]
                    dw_self_gd=pces_prop['sp_res']
                    n_pix_calc=np.int(np.ceil((pces_prop['lb_Bds'][Bd_id][-1]-min_lb_Bd+dw_self_gd)/dw_self_gd))                                
                    pces_prop['n_pix_calc'][Bd_id]=n_pix_calc
                    pces_prop['lb_Bds_calc'][Bd_id]=min_lb_Bd-0.5*dw_Bd + np.arange(n_pix_calc)*dw_self_gd
            fxI={'Ca_mode':'ls'}
            pces_prop['vl_Bd_calc']={}
            pces_prop['vl_Bd_lowbd_calc']={}
            pces_prop['vl_Bd_highbd_calc']={}
            pces_prop['dvl_Bd_calc']={}                        
            for Bd_id in pces_prop['Bds']:
                vl_Bd_calc=c_lt*((pces_prop['lb_Bds_calc'][Bd_id]/pces_prop['w0'])-1.) 
                pces_prop['vl_Bd_calc'][Bd_id]=vl_Bd_calc
                dvl_Bd_calc=vl_Bd_calc[1]-vl_Bd_calc[0]
                pces_prop['dvl_Bd_calc'][Bd_id]=dvl_Bd_calc
                pces_prop['vl_Bd_lowbd_calc'][Bd_id]=vl_Bd_calc-0.5*dvl_Bd_calc
                pces_prop['vl_Bd_highbd_calc'][Bd_id]=vl_Bd_calc+0.5*dvl_Bd_calc
            fxI.update({'lambda_0':pces_prop['lambda_0'],'hwhm_lor':pces_prop['hwhm_lor'],'sigma_vu0':pces_prop['sigma_vu0'],'gg':dic_sp_Tp['gg'],
'delta_damping':pces_prop['delta_damping']})
            pces_prop['pt']={}
            pces_prop['pt']['cs_Ca_func']=return_crs('pt',Ca_proc,local_outputs,fxI)
            pces_prop['pt']['colRh_metapt']=1e26/pow(sn['db']*AU_1_m,2.)
            if sp not in tabt['Ca_ls_sp']:
                tabt['Ca_ls_sp']+=[sp]
            pces_prop['aat']={}
            pces_prop['aat']['cs_Ca_func']=return_crs('aat',Ca_proc,local_outputs,fxI)
            for by in dsp_anreg: 
                if ('aat' in dsp_anreg[by]):
                    dspba=dsp_anreg[by]['aat']
                    if by not in greg['Ca_bys_atm']:
                        greg['Ca_bys_atm'][by]=[sp]
                    elif sp not in greg['Ca_bys_atm'][by]:
                        greg['Ca_bys_atm'][by]+=[sp]
                    if (local_outputs['vl_for_Caproc']==True) and ('An_vl_func' not in dspba):
                        dspba['An_vl_func']=An_vl_functions(dspba)
            abp[Ca_proc]=pces_prop
        dic_sp_Tp['vl_for_Caproc']=local_outputs['vl_for_Caproc']
        dic_sp_Tp['Tp_for_Caproc']=local_outputs['Tp_for_Caproc']
        dic_sp_Tp['Ca_proc']=dic_sp_Tp['Ca_proc'].keys()
        dic_sp_Tp['pRd_proc']={'tr1':{},'tr2':{},'tr3':{}} 
        for pRd_proc in dic_sp_Tp['pRd_proc']:
            pces_prop=dic_sp_Tp['pRd_proc'][pRd_proc]
            pces_prop.update(Dc_all_pceses[pRd_proc])
            if (sp not in tabt['etr_pRd_proc']):tabt['etr_pRd_proc'][sp]=[]                     
            tabt['etr_pRd_proc'][sp]+=[pRd_proc]
            def_prop_loc(pces_prop,dsm)
            pces_prop['Bds']=[]
            pces_prop['lb_Bds']={}
            pces_prop['n_pix']={}
            pces_prop['ipix_Bds_gb']=np.empty(0,dtype=int)
            for Bd_id in tabt['Bds_order']:
                Bd_set=Bd_dtss[Bd_id]
                wov=np.where((Bd_set['rlbT']>=pces_prop['w0']*((-300./c_lt)+1.)) & (Bd_set['rlbT']<=pces_prop['w0']*((100./c_lt)+1.)))[0]    
                if len(wov)>0:
                    pces_prop['Bds']+=[Bd_id]
                    if (Bd_id not in Dc_ltproc['pRd']):
                        Dc_ltproc['pRd']+=[Bd_id]
                    pces_prop['lb_Bds'][Bd_id]=Bd_set['rlbT'][wov]
                    pces_prop['n_pix'][Bd_id]=len(wov)
                    pces_prop['ipix_Bds_gb']=np.append(pces_prop['ipix_Bds_gb'],tabt['ipix_st_end'][Bd_id][0]+wov)
            pces_prop['lb_allBds']=tabt['lb_gb'][pces_prop['ipix_Bds_gb']]
            fxI={'lb_allBds':pces_prop['lb_allBds'],
                          'dlb_allBds':tabt['dlb_gb'][pces_prop['ipix_Bds_gb']]}                     
            fxI['Fone']=tabt['Fone_gb'][pces_prop['ipix_Bds_gb']]
            fxI.update({'nlb_allBds':len(pces_prop['lb_allBds']),'sigma_vu0':pces_prop['sigma_vu0'],'gg':dic_sp_Tp['gg'],'MSr':ts['MSr']})
            lb_allBds=fxI['lb_allBds']
            rb_fx_profile = (AU_1_m)**2.*(lb_allBds*lb_allBds)*1e-19*fxI['sigma_vu0']/(fxI['gg']*c_lt**2.*G_usi*fxI['MSr']*Msun)
            rb_profile = fxI['Fone']*rb_fx_profile
            def rb_func_loc(var_inputs):
                return np_interp(var_inputs['lb_pt_tab'],lb_allBds,rb_profile, left=0.,right=0.) 
            pces_prop['rb_func']=rb_func_loc
            d_PrP[pRd_proc]=pces_prop
        dic_sp_Tp['pRd_proc']=dic_sp_Tp['pRd_proc'].keys()
        dic_sp_Tp['sid_on']=True
        PhI_dic={}
        dic_sp_Tp['PhI']=PhI_dic
        PhI_dic['Bds']=[]
        PhI_dic['ipix_last_gb']=np.empty(0,dtype=int)
        for Bd_id in tabt['Bds_order']:
            Bd_set=Bd_dtss[Bd_id]
            if (Bd_set['rlbT'][0]<=dic_sp_Tp['t']):
                PhI_dic['Bds']+=[Bd_id]
                if (Bd_id not in Dc_ltproc['Ph']):
                    Dc_ltproc['Ph']+=[Bd_id]
                if (Bd_set['rlbT'][-1]<=dic_sp_Tp['t']):
                    wov=np_arange(len(Bd_set['rlbT']))
                else:
                    wov=np_where1D(Bd_set['rlbT']<=dic_sp_Tp['t'])
                PhI_dic['ipix_last_gb']=np.append(PhI_dic['ipix_last_gb'],tabt['ipix_st_end'][Bd_id][0]+wov)
        PhI_dic['lb_allBds']=tabt['lb_gb'][PhI_dic['ipix_last_gb']]
        fxI={'lb_allBds':PhI_dic['lb_allBds']}
        fxI['Fone']=tabt['Fone_gb'][PhI_dic['ipix_last_gb']]
        cs_lb_prof=1e-16*crs_sp(fxI['lb_allBds'])*fxI['lb_allBds']/(h_planck*c_lt)
        Ph_Rt_one=integrate.trapz(fxI['Fone']*cs_lb_prof, x= fxI['lb_allBds'])
        def Ph_func_loc(var_inputs):
            return Ph_Rt_one/(var_inputs['dist_Sr_pt']*var_inputs['dist_Sr_pt'])
        PhI_dic['PhRt_func']=Ph_func_loc    
        PhI_dic['Ph_Rt_one']=Ph_Rt_one          
        Rde_dic={}        
        dic_sp_Tp['Rde']=Rde_dic
        Rde_dic['De_sp']=['spl']
        Rde_dic['Rde_Rts']={'spl':1.2706480304955527e-04}
        def def_f_l(Dc_loc,prop_loc):
            funcname='AnP_hy' if prop_loc=='Rh' else 'AnP_cst'
            Dc_loc[prop_loc]['function']=Anreg_functions[funcname][0]
        for by in dsp_anreg:
            Dc_an_atm=dsp_anreg[by]['aat']
            greg['by_Antm_sp'][by].update([sp])
            if ('Rh' in Dc_an_atm):def_f_l(Dc_an_atm,'Rh')
            if ('Tp'      in Dc_an_atm):def_f_l(Dc_an_atm,'Tp')           	        		
            if ('Up_VL'  in Dc_an_atm):def_f_l(Dc_an_atm,'Up_VL')
        gsgreg[sp]=dsp_anreg
        Dc_gases[sp]=dic_sp_Tp
    Ca_ls_Bds=list(set(Ca_ls_Bds_by+Ca_ls_Bds_proc))
    tabt['Ca_ls_Bds']=[] 
    tabt['Ca_ls_Bds_by']=[] 
    tabt['Ca_ls_Bds_proc']=[]       
    for Bd_id in tabt['Bds_order']:
        if Bd_id in Ca_ls_Bds:tabt['Ca_ls_Bds']+=[Bd_id]            
        if Bd_id in Ca_ls_Bds_by:tabt['Ca_ls_Bds_by']+=[Bd_id]  
        if Bd_id in Ca_ls_Bds_proc:tabt['Ca_ls_Bds_proc']+=[Bd_id]
    if (len(tabt['Ca_ls_Bds_proc'])>0):
        ist_Bd=0
        ipix_st_end={}
        for Bd_id in tabt['Ca_ls_Bds_proc']:
            Bd_set=Bd_dtss[Bd_id]
            ipix_st_end[Bd_id]=[ist_Bd,ist_Bd+Bd_set['npix']-1]
            ist_Bd+=Bd_set['npix']
        tabt['Ca_ls_npix_gb']=ist_Bd
        tabt['Ca_ls_ipix_st_end']=ipix_st_end
        tabt['plCa_ls_Bds_pix']={}
        for Bd_id in tabt['Ca_ls_Bds_pix']:
            tabt['Ca_ls_Bds_pix'][Bd_id]=np.array(list(tabt['Ca_ls_Bds_pix'][Bd_id]))
            all_Bd_idx=np.arange(Bd_dtss[Bd_id]['npix'])
            tabt['plCa_ls_Bds_pix'][Bd_id]=np.delete(all_Bd_idx,tabt['Ca_ls_Bds_pix'][Bd_id])
    dsm['sp_list']=sp_list
    return Dc_gases,abp,d_PrP,gsgreg,tabgs,sid_index
