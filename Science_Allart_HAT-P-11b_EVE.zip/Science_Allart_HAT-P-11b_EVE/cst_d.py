# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
from math import pi
AU_1=149597870.7
AU_1_m=AU_1*1e3
AU_1_cm=AU_1_m*1e2
pc_1=648000./pi
c_lt=299792.458
c_lt_m=299792458.
Msun=1.988415829e30
Rsun=695700.
Lsun=382.8*1e24
Mjup=1.898130285e27
Rjup=71492.
Mnept=102.42e24
Rnept=24764.
Msn=5.972186e24
Rsn=6378.1
G_usi=6.67428e-11
sig_sb=5.670373*1e-8
amu=1.660531e-27
k_boltz=1.3806488*1e-23
h_planck=6.62606957e-34
alpha=2.654008849418e-06
tabg={'spg':{'g':4.002602,'t':2593.01},}
for elem in tabg:
    if ('g' in tabg[elem]):tabg[elem]['gg']=tabg[elem]['g']*amu
 
