# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
from cst_d import G_usi,k_boltz,AU_1_m,Msun,AU_1_cm
from math import pi,sqrt
def AnP_cst(n_pos,r_pos,prop,ts,dg_ab,dsp_anreg):
    return np.repeat(dsp_anreg[prop]['constr'].values()[0],n_pos)
def AnP_hy(n_pos,r_pos,prop,ts,dg_ab,dsp_anreg): 
    return dsp_anreg['Rh']['constr']['Rh']*np.exp( (G_usi*dg_ab['mn_m']*ts['MPl']*Msun/(k_boltz*dsp_anreg['Tp']['constr']['Tp']))*( (1./r_pos)-(1./(dsp_anreg['Rh']['constr']['Rd']*ts['RPl']) ) )/AU_1_m  )
Anreg_functions={'AnP_cst':[AnP_cst,[]],'AnP_hy':[AnP_hy,['r']],}
def An_vl_functions(dsp_anreg):
    return plUp_vl
def plUp_vl(ang_Cd_by,vlpl,dsp_anreg,ts,dg_ab,n_pos,x_pos,y_pos,rxy_pos,z_pos,r_pos):    
    return vlpl-dsp_anreg['Up_VL']['function'](n_pos,r_pos,'Up_VL',ts,dg_ab,dsp_anreg)*((x_pos*ang_Cd_by['s_dzet_pl+om_Rd'] + y_pos*ang_Cd_by['c_dzet_pl+om_Rd'])*ang_Cd_by['c_inc'] - z_pos*ang_Cd_by['s_inc'])/r_pos                                                                                                         
def Rh_ts_pt(Cd_pl_pt,d_pl_pt,Dc_gen_Antm,UpVL_ts,ThVL_ts,dt_s,n_atom_per_pt,ts,itsimu,by):
    Rd_up=Dc_gen_Antm['Rd_ts']+(UpVL_ts+ThVL_ts)*dt_s
    Rd_ts_lim=	0.999*Dc_gen_Antm['Rd_ts']
    return np.sum(((d_pl_pt >= Rd_ts_lim) & (d_pl_pt <= Rd_up)))*n_atom_per_pt/(4.*pi*(( Rd_up**3.-Rd_ts_lim**3. )/3.)*(AU_1_cm**3.) )  ,sqrt(Rd_ts_lim*Rd_up)
