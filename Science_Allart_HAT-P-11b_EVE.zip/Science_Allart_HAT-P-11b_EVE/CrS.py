# -*- coding: utf-8 -*-
"""
@author: V. Bourrier
"""
import numpy as np
from cst_d import k_boltz
from math import sqrt,pi
from scipy import special
from bas_f import np_interp
def return_crs(reg,pces_name,locO,fixI):
    if (reg=='pt'):   
            def crs_loc(var_inputs):
                return crsL(var_inputs['vl_pt'],var_inputs['vl_Bd_lowbd'],var_inputs['vl_Bd_highbd'],var_inputs['dvl_Bd'],fixI['lambda_0'],fixI['hwhm_lor'],fixI['sigma_vu0'])
            crs_func=crs_loc
    if (reg=='aat'):
            locO['vl_for_Caproc']=True
            locO['Tp_for_Caproc']=True
            def crs_loc(var_inputs):
                return crsV(var_inputs['Tp_gas'],var_inputs['vl_gas'],var_inputs['hvrange_Ca'],var_inputs['vl_Bd_lowbd'],var_inputs['vl_Bd_highbd'],var_inputs['vl_Bd'],var_inputs['dvl_Bd'],var_inputs['n_pix'],fixI['gg'],fixI['hwhm_lor'],fixI['sigma_vu0'],fixI['lambda_0'])
            crs_func=crs_loc   
    return crs_func
def crsL(vl_pt,vl_lowbd,vl_highbd,dv_bin,lambda_0,hwhm_lor,sigma_vu0):
    return sigma_vu0*(lambda_0/pi)*(np.arctan( (vl_highbd-vl_pt)/hwhm_lor )-np.arctan( (vl_lowbd-vl_pt)/hwhm_lor ))/(dv_bin*1e3)
def crsV(Tp_gas,vl_gas,hvrange_Ca,vl_Bd_lowbd,vl_Bd_highbd,vl_Bd,dvl_Bd,n_pix,mu_kg,hwhm_lor,sigma_vu0,lambda_0):
    DoW=np.sqrt(2.*k_boltz*Tp_gas/mu_kg)*1e-3
    aV=hwhm_lor/DoW	
    rgV,dvV=np.array([-2.*hvrange_Ca,2.*hvrange_Ca]),np.array([dvl_Bd])
    n_HRbs=(np.round(dvl_Bd/dvV)).astype(int)
    d_HRbs=dvl_Bd/n_HRbs
    n_HRbs=dict(zip(d_HRbs,n_HRbs))
    i_rgV_lowbound=np.searchsorted(rgV+vl_gas,vl_Bd_lowbd)-1
    i_rgV_highbound=np.searchsorted(rgV+vl_gas,vl_Bd_highbd)-1
    cond_upsamp=(abs(vl_Bd-vl_gas) < rgV[-1]-0.5*dvl_Bd)
    in_rgV=np.where( cond_upsamp )[0]
    tab=np.zeros(n_pix)
    for i_vl,vl_bin in zip(in_rgV,vl_Bd[in_rgV]):
        d_HRb=min(d_HRbs[range(i_rgV_lowbound[i_vl],i_rgV_highbound[i_vl]+1)])
        tab[i_vl]=np.sum(Unr_Voigt(aV,-(vl_bin-0.5*dvl_Bd+d_HRb*(0.5+np.arange(n_HRbs[d_HRb]))-vl_gas)/DoW))/n_HRbs[d_HRb]
    out_rgV=np.invert(cond_upsamp) 							
    if True in out_rgV:
	    tab[out_rgV]=Unr_Voigt(aV,-(vl_Bd[out_rgV]-vl_gas)/DoW)
    return tab*sigma_vu0*lambda_0/(sqrt(pi)*DoW*1e3)
def Unr_Voigt(a,u):
    z = u + 1j*a
    return special.wofz(z).real 
def crs_sp(lb_Bd):
    lb_tab = np.array([209.49,219.59,230.71 ,243.01 ,256.70 ,271.21, 271.94 ,331.36 ,357.34 ,387.75 ,423.81 ,467.27 ,520.65 ,587.81 ,674.86 ,792.18 ,958.87 ,1214.41 ,1655.63 ,2023.15 ,2275.74 ,2528.27 ,2593.01])
    df_de_tab = np.array([0.1537 ,0.1750 ,0.200 ,0.231 ,0.274 ,0.338 ,0.343 ,0.0520 ,0.0325 ,0.0310 ,0.0358 ,0.0461 ,0.0557 ,0.0620 ,0.0780 ,0.1138 ,0.1572 ,0.247 ,0.435 ,0.501 ,0.537 ,0.589 ,0.605])
    sv=np.zeros(len(lb_Bd))
    sv[(lb_Bd<=2593.01)]=8.0670e-22*np_interp(lb_Bd[(lb_Bd<=2593.01)],lb_tab,df_de_tab)
    return sv     

